﻿using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SendMessage
{
    public class SendMessages
    {
        public void Send(IConnection connection, string queue)
        {
          

            try
            {
                using (var channel = connection.CreateModel())
                {

                    channel.ExchangeDeclare("Respuesta", ExchangeType.Direct, true, false, null);

                    channel.QueueDeclare("ColasRespuesta", true, false, false, null);

                    channel.QueueBind("ColasRespuesta", "Respuesta", "optional-routing-key");


                    var properties = channel.CreateBasicProperties();
                    properties.DeliveryMode = 1;
                    properties.ClearMessageId();
                    properties.ReplyTo = "Respuesta";
                    var encoding = new UTF8Encoding();
                    var hour = DateTime.Now.Hour;
                    var min = DateTime.Now.Minute;
                    var sec = DateTime.Now.Second;
                    var msg = string.Format(@"He recibido tu mensajes desde Ping! Hora:{0} : {1} : {2}", hour,min,sec);
                    var msgBytes = encoding.GetBytes(msg);

                    channel.BasicPublish("Respuesta", "optional-routing-key", false, properties, msgBytes);
                    Thread.Sleep(2000);
                    channel.Close();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
            }


        }
    }
}
