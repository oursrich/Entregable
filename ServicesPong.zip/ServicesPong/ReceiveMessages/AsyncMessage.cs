﻿using RabbitMQ.Client;
using SendMessage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ReceiveMessages
{
    public class AsyncMessage
    {
        public IConnection Connect()
        {


            try
            {

                IConnection connection = new ConnectionFactory().CreateConnection();
                return connection;
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                IConnection connection = null;
                return connection;
            }


        }
        public void AsyncMessages(string queue)
        {
            ReceiveMessage send = new ReceiveMessage();
            IConnection connection = Connect();
            if (connection.IsOpen)
            {

                var thread = new Thread(o => send.Receive(connection, queue));
                thread.Start();

                while (!thread.IsAlive)
                    Thread.Sleep(2);
            }
        }
        public void AsyncMessageReceive(string queue)
        {
            SendMessages send = new SendMessages();
            IConnection connection = Connect();
            if (connection.IsOpen)
            {

                var thread = new Thread(o => send.Send(connection, queue));
                thread.Start();

                while (!thread.IsAlive)
                    Thread.Sleep(2);
            }
        }
    }
}
