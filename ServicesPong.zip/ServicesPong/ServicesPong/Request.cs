﻿using ReceiveMessages;
using System;
using System.IO;
using System.Net.Sockets;

namespace ServicesPong
{
    public class Request
    {
        public string Command;
        public string Path;
        public string Protocol;
        private static string NOTFOUND404 = "HTTP/1.1 404 Not Found";
        private static string OK200 = "HTTP/1.1 200 OK\r\n\r\n\r\n";
        private string home;
        public void ProcessRequest(Request request, NetworkStream stream)
        {
            if (request == null)
            {
                return;
            }
            if (request.Path.Equals("/"))
                request.Path = "/home.html";
            ParsePath(request);
            if (File.Exists(request.Path))
            {
                var fileContent = File.ReadAllText(request.Path);
                GenerateResponse(fileContent, stream, OK200);
                return;
            }

            GenerateResponse("Not found", stream, NOTFOUND404);
        }

        private void ParsePath(Request request)
        {
            request.Path.Replace('/', '\\');
            request.Path = home + request.Path;
        }

        private void GenerateResponse(string content,
            NetworkStream stream,
            string responseHeader)
        {
            string response = "HTTP/1.1 200 OK\r\n\r\n\r\n";
            response = response + content;
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(response);
            stream.Write(msg, 0, msg.Length);
            return;
        }
        public Request GetRequest(string data)
        {
            Request datos = new Request();
            AsyncMessage send = new AsyncMessage();
            send.AsyncMessages("Servicios");

            return datos;
        }

    }
}